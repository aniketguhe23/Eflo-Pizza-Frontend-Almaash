"use client";

import Image from "next/image";
import { useRef } from "react";

const featuredItems = [
  {
    title: "MOST POPULER 7-CHEESE PIZZA",
    price: "INR 410 / 699 / 864",
    image: "/ps1.png",
  },
  {
    title: "MUST TRY TANDOORI FEAST PIZZA",
    price: "INR 308 / 510 / 730",
    image: "/pizzacopy.png",
  },
  {
    title: "FAN FAVOURITE STUFFED GARLIC STICKS",
    price: "INR 200",
    image: "/featuredPizza3.png",
  },
];

export default function FeaturedSlider() {
  const scrollRef = useRef<HTMLDivElement>(null);

  const scroll = (direction: "left" | "right") => {
    if (scrollRef.current) {
      scrollRef.current.scrollBy({
        left: direction === "left" ? -400 : 400, // Adjusted scroll distance
        behavior: "smooth",
      });
    }
  };

  return (
    <div className="bg-[#fdf1d8] py-10 text-black flex justify-center">
      <div className="w-full max-w-screen-lg text-center relative">
        <h2 className="text-4xl font-extrabold uppercase mb-10 [font-family:'Antonio',Helvetica]">
          Explore Featured Pizza’s
        </h2>

        <div className="relative flex items-center">
          {/* Left Arrow */}
          <button
            onClick={() => scroll("left")}
            className="absolute left-0 z-10 p-2 text-3xl font-bold"
          >
            &lt;
          </button>

          {/* Slider */}
          <div
            ref={scrollRef}
            className="flex gap-6 overflow-x-auto no-scrollbar px-12 scroll-smooth"
          >
            {featuredItems.map((item, index) => (
              <div
                key={index}
                className="bg-white rounded-xl p-8 shadow-lg flex flex-col items-center" // Adjusted padding
                style={{ height: "400px", width: "900px" }} // Increased height and width for cards
              >
                <h3 className="text-sm font-bold uppercase mb-3 text-center">
                  {item.title}
                </h3>
                <p className="text-sm text-[#f47335] mb-5 font-bold">
                  {item.price}
                </p>
                <div className="w-48 h-56 relative mb-6">
                  {" "}
                  {/* Increased image height and width */}
                  <Image
                    src={item.image}
                    alt={item.title}
                    fill
                    className="object-contain"
                  />
                </div>
                <button className="bg-[#f47335] text-white px-6 py-2 rounded-lg text-sm font-semibold mb-4 cursor-pointer [font-family:'Antonio',Helvetica]">
                  ORDER NOW
                </button>
                <p className="text-lg font-semibold cursor-pointer [font-family:'Antonio',Helvetica]">
                  MAKE IT MY OWN
                </p>
              </div>
            ))}
          </div>

          {/* Right Arrow */}
          <button
            onClick={() => scroll("right")}
            className="absolute right-0 z-10 p-2 text-3xl font-bold"
          >
            &gt;
          </button>
        </div>
      </div>
    </div>
  );
}
