import Image from "next/image";
import DecorativeImages from "./DecorativeImages";

export default function PopularDishes() {
  const decorativePositions = [
    { top: "10%", left: "5%" },
    { top: "20%", left: "75%" },
    { top: "30%", left: "25%" },
    { top: "40%", left: "85%" },
    { top: "60%", left: "65%" },
    { top: "70%", left: "35%" },
  ];

  return (
    <div className="bg-[#f8f3e3] py-8 px-4 md:px-12 text-center relative">
      <DecorativeImages positions={decorativePositions} />

      <h2 className="text-6xl tracking-widest mb-8 text-black [font-family:'Aclonica',Helvetica]">
        <span className="inline-block mx-4">P</span>
        <span className="inline-block mx-4">O</span>
        <span className="inline-block mx-4">P</span>
        <span className="inline-block mx-4">U</span>
        <span className="inline-block mx-4">L</span>
        <span className="inline-block mx-4">A</span>
        <span className="inline-block mx-4">R</span>
        <span className="inline-block mx-15">D</span>
        <span className="inline-block mx-4">I</span>
        <span className="inline-block mx-4">S</span>
        <span className="inline-block mx-4">H</span>
        <span className="inline-block mx-4">E</span>
        <span className="inline-block mx-4">S</span>
      </h2>
    </div>
  );
}
