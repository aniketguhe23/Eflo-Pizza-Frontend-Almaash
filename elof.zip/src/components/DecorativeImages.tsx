// components/DecorativeImages.tsx
import Image from "next/image";

interface DecorativeImagesProps {
  positions: { top: string; left: string }[];
}

export default function DecorativeImages({ positions }: DecorativeImagesProps) {
  return (
    <>
      {positions.map((pos, i) => (
        <div
          key={i}
          className="absolute opacity-20"
          style={{ top: pos.top, left: pos.left }}
        >
          <Image src="/elephant.png" alt="Decorative logo" width={100} height={100} />
        </div>
      ))}
    </>
  );
}
