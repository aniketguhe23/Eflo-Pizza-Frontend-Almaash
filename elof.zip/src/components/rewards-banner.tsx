import Image from "next/image";
import Link from "next/link";

export default function RewardsBanner() {
  return (
    <div className="bg-white py-8 px-4 md:px-12 flex flex-col md:flex-row items-center justify-center gap-8">
      {/* Left side - Pizza image */}
      <div className="relative">
        <Image
          src="/pizza2.jpg"
          alt="Specialty Pizza"
          width={250}
          height={250}
          className="rounded-lg"
        />
        <div className="absolute -top-4 -left-4 opacity-30">
          {/* <Image src="/elephant-logo.png" alt="Decorative logo" width={60} height={60} /> */}
        </div>
      </div>

      {/* Middle - Rewards image */}
      <div className="relative">
        <div className="relative">
          <Image
            src="/pizzatag.png"
            alt="Rewards Dish"
            width={150}
            height={150}
            className=""
          />
        </div>
      </div>

      {/* Right side - Rewards info */}
      <div className="bg-gradient-to-l from-[#ffc2a0] to-white rounded-lg p-6 max-w-xs text-black">
  <h3 className="font-bold text-lg">JOIN ELFO'S REWARDS</h3>
  <p className="font-bold">
    UNLOCK <span className="text-red-600">FREE CHIPOTLE</span>.
  </p>

  <div className="flex justify-between mt-4">
    <Link href="/account/create">
      <button className="text-sm font-semibold bg-white text-black px-4 py-2 rounded">
        CREATE AN ACCOUNT
      </button>
    </Link>
    <Link href="/account/login">
      <button className="text-sm font-semibold text-black px-4 py-2 rounded">
        SIGN IN
      </button>
    </Link>
  </div>
</div>

    </div>
  );
}
