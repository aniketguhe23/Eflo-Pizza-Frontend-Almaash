import Header from "@/components/header";
import HeroSection from "@/components/hero-section";
import RewardsBanner from "@/components/rewards-banner";
import PopularDishes from "@/components/popular-dishes";
import SpecialtiesSection from "@/components/specialties-section";
import Image from "next/image";
import FeaturedSlider from "@/components/featured-slider";
import WhyAtElfos from "@/components/why-ate-elfos";
import Footer from "@/components/footer";

export default function Home() {
  return (
    <main className="min-h-screen">
    <Header />
    <HeroSection />
    <RewardsBanner />
    <PopularDishes />
    <SpecialtiesSection />
    <FeaturedSlider />
    <WhyAtElfos />
    <Footer />
  </main>
  );
}
