import Image from "next/image"
import Link from "next/link"
import { MapPin, ShoppingCart, User } from "lucide-react"

export default function Header() {
  return (
    <header className="flex flex-col md:flex-row items-center justify-between px-6 py-4 md:px-12 bg-[#f47335]">
      <div className="flex items-center gap-4">
        <Image src="/elephant.png" alt="Elfo's Pizza Logo" width={100} height={100} className="w-10 h-10" />
        <h1 className="text-white text-2xl font-bold">ELFO'S PIZZA</h1>
      </div>

      <nav className="hidden md:flex items-center gap-8">
        <Link href="/" className="text-white font-semibold border-b-2 border-white pb-1">
          HOME
        </Link>
        <Link href="/build" className="text-white font-semibold hover:border-b-2 hover:border-white pb-1">
          BUILD YOUR OWN
        </Link>
        <Link href="/menu" className="text-white font-semibold hover:border-b-2 hover:border-white pb-1">
          MENU
        </Link>
      </nav>

      <div className="flex items-center gap-4 mt-4 md:mt-0">
        <div className="bg-[#c05a29] text-white rounded-md flex items-center p-2 max-w-xs">
          <MapPin className="text-white mr-2 h-5 w-5" />
          <div className="flex flex-col">
            <span className="text-xs">Delivery From</span>
            <span className="text-xs">Select your address</span>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <div className="bg-white text-[#f47335] px-3 py-1 rounded-md font-semibold">Delivery</div>
          <div className="bg-transparent text-white border border-white px-3 py-1 rounded-md font-semibold">
            Pickup/Dine in
          </div>
        </div>

        <User className="text-white h-6 w-6" />

        <div className="relative">
          <ShoppingCart className="text-white h-6 w-6" />
          <span className="absolute -top-2 -right-2 bg-white text-[#f47335] rounded-full w-5 h-5 flex items-center justify-center text-xs font-bold">
            0
          </span>
        </div>
      </div>
    </header>
  )
}
